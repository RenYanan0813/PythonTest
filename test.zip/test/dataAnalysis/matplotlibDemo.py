#c:/python36/

#-*- coding: utf-8 -*-
# python version: 3.6

__author__ = "renyanan"

import matplotlib.pyplot as plt

plt.plot([1,2,4],[7,3,9])
plt.show()