#c:/python2715/
#-*- coding: utf-8 -*-

data = (
    {
        'id': '162',
        'user': "reg_user",
        'pw': "oracle123!",
        'dsn': "180.2.35.162:1521/djtest",
        'sql_txt': './sql.txt'
    },

    {
        'id': '16',
        'user': "reg_user",
        'pw': "oracle123!",
        'dsn': "180.2.34.16:1521/sgehisdb",
        'sql_txt': './sql.txt'
    }
)

table1 = "162"
user1 = "reg_user"
pw1 = "oracle123!"
dsn1 = "180.2.35.162:1521/djtest"

table2 = "16"
user2 = "reg_user"
pw2 = "oracle123!"
dsn2 = "180.2.34.16:1521/sgehisdb"

# sql_txt = '/home/zhiban/hjx/ryn/exp-diff/sql.txt'
sql_txt = 'D:\\gitRepository\\PythonTest\\test\\exp-diff\\sql.txt'