

" this is only ---- create text file"

import os

ls = os.linesep