

def OneMonthCount():
	hoursCount