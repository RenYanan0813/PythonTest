# -*- coding:utf-8 -*-

"""
服务器信息
"""

qtesvr_a = {
    "hostname": '180.2.34.23',
    "username": 'qte',
    "psw": 'qte'
}

qtesvr_b = {
    "hostname": '180.2.34.24',
    "username": 'qte',
    "psw": 'qte'
}