# -*- coding:utf-8 -*-

#新版前置svr信息
new_svr_info = {
    'hostname': '180.2.35.130', #服务器地址
    'username': 'zhiban', #服务器用户名
    'password': 'zhiban', #服务器密码
    'new_svr_address': '', #最新服务路径
    'new_svr_tar': '', #最新服务的tar包
}

#中转文件本地信息，即文件下载、更改配置文件的本地目录，默认在d盘
local_svr = {
    'local_address': 'd:\\svrconfig\\', #存储在本地的路径(最后要加'\\')
}